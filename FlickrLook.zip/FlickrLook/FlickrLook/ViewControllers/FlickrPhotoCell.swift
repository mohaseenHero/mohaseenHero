//
//  FlickrPhotoCell.swift
//  FlickrLook
//
//  Created by Mohaseen TmmT on 17/07/21.
//

import UIKit

class FlickrPhotoCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView?
    @IBOutlet weak var imgBtn: UIButton?
}
